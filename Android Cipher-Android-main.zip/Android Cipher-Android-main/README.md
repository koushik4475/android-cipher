# Encryption-Decryption-Android
This repository is about how to encrypt and decrypt a text in Android.
